<div class="container my-5" style="min-height: calc(100vh - 40px);">
	<h1 class="text-center">Syarat dan Ketentuan</h1>
	<div class="col-10 offset-1 col-md-8 offset-md-2 mt-5">
		<div style="max-width: 90%; height: auto; margin-left: auto; margin-right: auto; margin-top: 5%; display: block; font-size: 15px;">
			teks disini
		</div>
	</div>
</div>