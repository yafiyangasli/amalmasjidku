<section class="home-section">
  <div class="text">Donasi anda yang sudah tersalurkan</div>
  <div class="container-fluid">
    <div class="table-responsive-md">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">No</th>
          <th scope="col">Tanggal</th>
          <th scope="col">Program</th>
          <th scope="col">Total Donasi</th>
          <th scope="col">Detail</th>

        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">1</th>
          <td>21 Januari 2021</td>
          <td>Penghypebeast an anak-anak indonesia</td>
          <td>Rp. 100.000.000</td>
          <td><a href="" class="btn btn-success">Lihat</a></td>
        </tr>
      </tbody>
    </table>
    </div>
  </div>
</section>