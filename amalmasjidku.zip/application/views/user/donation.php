<section class="home-section">
  <div class="text">Donasi Anda</div>
  <div class="container-fluid">
    <div class="table-responsive-md">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Tanggal</th>
          <th scope="col">Invoice</th>
          <th scope="col">Nama</th>
          <th scope="col">Donasi</th>
          <th scope="col">Pembayaran</th>
          <th scope="col">Status</th>
          <th scope="col">Detail</th>

        </tr>
      </thead>
      <tbody>
        <?php foreach($donatur as $dt):?>
        <tr>
          <td><?= $dt['tanggal'];?></td>
          <th>Invoice</th>
          <td><?=$dt['nama'];?></td>
          <td><?=rupiah($dt['nominal']);?></td>
          <td><?=$dt['pembayaran'];?></td>
          <td><?=$dt['status'];?></td>
          <td><a href="<?=base_url('user/detailDonasi/').$dt['id_donatur'];?>" class="btn btn-info">Lihat</a></td>
        </tr>
      <?php endforeach;?>
      </tbody>
    </table>
    </div>
  </div>
</section>